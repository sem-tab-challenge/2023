import pandas as pd
import json
import os
from os import listdir, makedirs
from os.path import join, realpath, exists


class TD_Evaluator:
    def __init__(self, answer_file_path, round=1):
        """
        `round` : Holds the round for which the evaluation is being done.
        can be 1, 2...upto the number of rounds the challenge has.
        Different rounds will mostly have different ground truth files.
        """
        self.answer_file_path = answer_file_path
        self.round = round

    def _evaluate(self, client_payload, _context={}):
        """
        `client_payload` will be a dict with (atleast) the following keys :
          - submission_file_path : local file path of the submitted file
          - aicrowd_submission_id : A unique id representing the submission
          - aicrowd_participant_id : A unique id for participant/team submitting (if enabled)
        """
        submission_file_path = client_payload["submission_file_path"]
        aicrowd_submission_id = client_payload["aicrowd_submission_id"]
        aicrowd_participant_uid = client_payload["aicrowd_participant_id"]

        gt_pair_prop = dict()
        gt = pd.read_csv(self.answer_file_path, delimiter=',', names=['tab_id', 'entity'],
                         dtype={'tab_id': str, 'entity': str }, keep_default_na=False)

        gt_NILs = []
        for index, row in gt.iterrows():
            cell = '%s' % (row['tab_id'])
            gt_pair_prop[cell] = row['entity']
            if row['entity'] == 'NIL':
                gt_NILs += [cell]

        correct_cells, annotated_cells = set(), set()
        sub = pd.read_csv(submission_file_path, delimiter=',', names=['tab_id', 'entity'],
                          dtype={'tab_id': str, 'entity': str}, keep_default_na=False)

        sub_cells = []
        for index, row in sub.iterrows():
            cell = '%s' % (row['tab_id'])
            sub_cells += [cell]
            if cell in gt_pair_prop:
                if cell in annotated_cells:
                    raise Exception("Duplicate records in the submission file")
                else:
                    annotated_cells.add(cell)
                annotation = row['entity'].split(',')[0]

                if annotation == 'NIL' or annotation.startswith('http://www.wikidata.org/entity/'):
                    gt_ents = gt_pair_prop[cell].split(',')
                    if annotation in gt_ents:
                        correct_cells.add(cell)

        # iterate if there is NIL in the gt and not in the submission
        # [correct_cells.add(nil_cell) for nil_cell in gt_NILs if nil_cell not in sub_cells]

        precision = len(correct_cells) / len(annotated_cells) if len(annotated_cells) > 0 else 0.0
        recall = len(correct_cells) / len(gt_pair_prop.keys())
        f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
        main_score = f1
        secondary_score = precision
        print('%.3f %.3f %.3f' % (f1, precision, recall))

        """
        Do something with your submitted file to come up
        with a score and a secondary score.
    
        if you want to report back an error to the user,
        then you can simply do :
          `raise Exception("YOUR-CUSTOM-ERROR")`
    
         You are encouraged to add as many validations as possible
         to provide meaningful feedback to your users
        """
        _result_object = {
            "score": main_score,
            "score_secondary": secondary_score,
            "f1": f1,
            "precision": precision,
            "recall": recall,
        }
        return _result_object


if __name__ == "__main__":
    # Lets assume the the ground_truth is a CSV file
    # and is present at data/ground_truth.csv
    # and a sample submission is present at data/sample_submission.csv
    answer_file_path = join(realpath('..'), 'td_evaluator', 'gt', 'td_gt.csv')
    d = join(realpath('..'), 'td_evaluator', 'td_submissions')
    for ff in os.listdir(d):
        try:
            _client_payload = {}
            print(ff)
            _client_payload["submission_file_path"] = os.path.join(d, ff)
            _client_payload["aicrowd_submission_id"] = 1123
            _client_payload["aicrowd_participant_id"] = 1234

            # Instaiate a dummy context
            _context = {}
            # Instantiate an evaluator
            aicrowd_evaluator = TD_Evaluator(answer_file_path)
            # Evaluate
            result = aicrowd_evaluator._evaluate(_client_payload, _context)
            print(result)
        except Exception as e:
            print(f'{e}\n\n')
            continue
